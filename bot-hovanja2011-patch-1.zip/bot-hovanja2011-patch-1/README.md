Just try to build bot in Haskell
