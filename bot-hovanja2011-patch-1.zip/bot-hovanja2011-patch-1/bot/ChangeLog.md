# Changelog for bot

## Unreleased changes
