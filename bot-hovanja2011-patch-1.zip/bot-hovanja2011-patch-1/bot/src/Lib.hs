{-# LANGUAGE OverloadedStrings #-}

module Lib
 where
 
--data User = User {
--      ok :: Bool
--    , result  :: [SMTH]
--    } deriving (Generic, Show)



--instance FromJSON User where
--    parseJSON = withObject "User"$ \v -> User 
--        <$> v .: "ok"
--        <*> v .: "result"




someFunc :: IO ()

someFunc = putStrLn "someFunc"
