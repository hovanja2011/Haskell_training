# Probability_programming_haskell
Try to build instances for probability types, such as Functor, Monad

articles
main: https://web.engr.oregonstate.edu/~erwig/papers/PFP_JFP06.pdf

other: Practical Probabilistic Programming with Monads

maybe this: https://arxiv.org/pdf/1908.02062.pdf

