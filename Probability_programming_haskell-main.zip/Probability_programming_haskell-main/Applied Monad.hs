newtype Prob = Prob {toDouble :: Double}
  deriving (Show)

prob :: Double -> Prob
prob d = Prob d

-- Dist  is datatype of probability distributions
newtype Dist a = Dist {toArr :: [(a, Prob)]} 
  deriving Show

toUniform :: [a] -> Dist a
toUniform ss = Dist $ map (\x-> (x, Prob (1 / len) )) ss where len = fromIntegral $ length ss

type Event a = a-> Bool

eventProb :: Event a -> Dist a -> Prob
eventProb e d = Prob. sum. map (toDouble.snd) .filter (e.fst).toArr $ d

joinWith:: (a-> b-> c) -> Dist a -> Dist b -> Dist c
joinWith f da db = Dist [ (f a b, Prob $ pa * pb) | (a,Prob pa) <- toArr da , (b,Prob pb) <- toArr db   ]

instance Functor Dist where
    fmap f d = Dist [(f a, pa)| ( a, pa) <- toArr d]

instance Applicative Dist where
    pure a    = Dist [(a,Prob 1)] 
    df <*> da = Dist [ (f a, Prob $ pf*pa) | (f, Prob pf) <- toArr df  , (a, Prob pa) <- toArr da]

instance Monad Dist where
    return a     = Dist [(a,Prob 1)]
    Dist d >>= f = Dist [ (b, Prob $ pa * pb)| (a,Prob pa) <- d,  (b,Prob pb) <- toArr $ f a]
    fail  _      = Dist []

type Trans a = a -> Dist a









