import Data.List (sortOn)

data Tree a = Leaf | Node Integer a (Tree a) (Tree a) deriving (Show)
data Tree' a = Leaf' | Node' (Integer, Integer) a (Tree' a) (Tree' a) deriving (Show)

--building a binary tree from the list
fromList :: [(Integer, a)] -> Tree a
fromList [] = Leaf
fromList [(x, val)] = Node x val Leaf Leaf
fromList ss = Node x val (fromList l) (fromList r) where
    n=length ss
    (l,r') = splitAt (n `div` 2) ss
    (x, val) = head r'
    r = tail r'

--finding a common subtree
findSplitTree:: Tree a -> (Integer , Integer) -> Tree a
findSplitTree Leaf (x1,x2) = Leaf
findSplitTree (Node x val l r) (x1,x2) 
    | x > x2 = findSplitTree l (x1,x2) 
    | x < x1 = findSplitTree r (x1,x2)
    | otherwise = (Node x val l r)

--point selection in a node
getPointFromNode :: Tree a -> [(Integer, a)]
getPointFromNode Leaf = []
getPointFromNode (Node x val l r) =[(x, val)]

--selection of two subtrees
getUnderTree :: Tree a -> (Tree a, Tree a)
getUnderTree Leaf = (Leaf ,Leaf)
getUnderTree (Node x val l r) =(l,r)

--1-Dimensional Range Searching
oneRangeQuery :: Tree a -> (Integer , Integer) -> [(Integer, a)]
oneRangeQuery Leaf (x1,x2) = []
oneRangeQuery tree  (x1,x2) = nd ++ lftnd ++ rgtnd where
    tree' = findSplitTree tree (x1,x2)
    nd = getPointFromNode tree'
    (l,r) = getUnderTree tree'
    lftnd = oneRangeQuery l (x1,x2)
    rgtnd = oneRangeQuery r (x1,x2)

--flipping pairs in an array
replace :: [(Integer, Integer)] -> [(Integer, Integer)]
replace = map (\(l,r) -> (r,l))

--building a binary tree from the 2d-list
fromList2 :: [(Integer, Integer)] -> Tree' (Tree Integer)
fromList2 [] = Leaf'
fromList2 [(x,y)] = Node' (x,y) (Node y x Leaf Leaf) Leaf' Leaf'
fromList2 ss = Node' (x, y) (fromList ss') (fromList2 l) (fromList2 r) where
    n=length ss
    (l,r') = splitAt (n `div` 2) ss
    (x, y) = head r'
    r = tail r'
    ss' =  sortOn fst (replace ss)

--point selection in a 2d-node
getPointFromNode2 :: Tree' (Tree Integer) -> (Integer, Integer) -> [(Integer, Integer)]
getPointFromNode2 Leaf' (y1,y2) = []
getPointFromNode2 (Node' p val l r) (y1,y2) = oneRangeQuery val (y1,y2) 

--finding a common 2d-subtree
findSplitTree2:: Tree' (Tree Integer) -> (Integer , Integer) -> Tree' (Tree Integer)
findSplitTree2 Leaf' (x1,x2) = Leaf'
findSplitTree2 (Node' (x,y) val l r) (x1,x2) 
    | x > x2 = findSplitTree2 l (x1,x2) 
    | x < x1 = findSplitTree2 r (x1,x2)
    | otherwise = (Node' (x,y) val l r)

--selection of two 2d-subtrees
getUnderTree2 :: Tree' (Tree Integer) -> (Tree' (Tree Integer), Tree' (Tree Integer))
getUnderTree2 Leaf' = (Leaf' ,Leaf')
getUnderTree2 (Node' p val l r) =(l,r)

--2-Dimensional Range Searching
oneRangeQuery2 :: Tree' (Tree Integer) -> ((Integer , Integer) , (Integer , Integer)) -> [(Integer , Integer)]
oneRangeQuery2 Leaf' ((x1,y1),(x2,y2)) = []
oneRangeQuery2 tree  ((x1,y1),(x2,y2)) = sortOn fst (sortOn snd (replace nd)) where
    tree' = findSplitTree2 tree (x1,x2)
    nd = getPointFromNode2 tree' (y1,y2)

--example 
example = fromList2 [(1,2),(2,4),(3,1),(3,3),(3,6),(4,5),(5,2),(5,4),(5,6),(6,3),(6,4),(6,5)]
badRequest = ((2,0),(6,4))
badAnswer = oneRangeQuery2 example badRequest 
goodAnswer = [(2,4),(3,1),(3,3),(5,2),(5,4),(6,3),(6,4)]
