module 2DTree where

import Data.List (sortOn)
import 1DTree

--building a binary tree from the 2d-list
fromList2 :: [(Integer, Integer)] -> Tree' (Tree Integer)
fromList2 [] = Leaf'
fromList2 [(x,y)] = Node' (x,y) (Node y x Leaf Leaf) Leaf' Leaf'
fromList2 ss = Node' (x, y) (fromList ss') (fromList2 l) (fromList2 r) where
    n=length ss
    (l,r') = splitAt (n `div` 2) ss
    (x, y) = head r'
    r = tail r'
    ss' =  sortOn fst (replace ss)

--point selection in a 2d-node
getPointFromNode2 :: Tree' (Tree Integer) -> (Integer, Integer) -> [(Integer, Integer)]
getPointFromNode2 Leaf' (y1,y2) = []
getPointFromNode2 (Node' p val l r) (y1,y2) = oneRangeQuery val (y1,y2) 

--finding a common 2d-subtree
findSplitTree2:: Tree' (Tree Integer) -> (Integer , Integer) -> Tree' (Tree Integer)
findSplitTree2 Leaf' (x1,x2) = Leaf'
findSplitTree2 (Node' (x,y) val l r) (x1,x2) 
    | x > x2 = findSplitTree2 l (x1,x2) 
    | x < x1 = findSplitTree2 r (x1,x2)
    | otherwise = (Node' (x,y) val l r)

--selection of two 2d-subtrees
getUnderTree2 :: Tree' (Tree Integer) -> (Tree' (Tree Integer), Tree' (Tree Integer))
getUnderTree2 Leaf' = (Leaf' ,Leaf')
getUnderTree2 (Node' p val l r) =(l,r)

--2-Dimensional Range Searching
oneRangeQuery2 :: Tree' (Tree Integer) -> ((Integer , Integer) , (Integer , Integer)) -> [(Integer , Integer)]
oneRangeQuery2 Leaf' ((x1,y1),(x2,y2)) = []
oneRangeQuery2 tree  ((x1,y1),(x2,y2)) = sortOn fst (sortOn snd (replace nd)) where
    tree' = findSplitTree2 tree (x1,x2)
    nd = getPointFromNode2 tree' (y1,y2)