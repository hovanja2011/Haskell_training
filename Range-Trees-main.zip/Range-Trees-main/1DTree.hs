module 1DTree where

import Data.List (sortOn)

data Tree a = Leaf | Node Integer a (Tree a) (Tree a) deriving (Show)

--building a binary tree from the list
fromList :: [(Integer, a)] -> Tree a
fromList [] = Leaf
fromList [(x, val)] = Node x val Leaf Leaf
fromList ss = Node x val (fromList l) (fromList r) where
    n=length ss
    (l,r') = splitAt (n `div` 2) ss
    (x, val) = head r'
    r = tail r'

--finding a common subtree
findSplitTree:: Tree a -> (Integer , Integer) -> Tree a
findSplitTree Leaf (x1,x2) = Leaf
findSplitTree (Node x val l r) (x1,x2) 
    | x > x2 = findSplitTree l (x1,x2) 
    | x < x1 = findSplitTree r (x1,x2)
    | otherwise = (Node x val l r)

--point selection in a node
getPointFromNode :: Tree a -> [(Integer, a)]
getPointFromNode Leaf = []
getPointFromNode (Node x val l r) =[(x, val)]

--selection of two subtrees
getUnderTree :: Tree a -> (Tree a, Tree a)
getUnderTree Leaf = (Leaf ,Leaf)
getUnderTree (Node x val l r) =(l,r)

--1-Dimensional Range Searching
oneRangeQuery :: Tree a -> (Integer , Integer) -> [(Integer, a)]
oneRangeQuery Leaf (x1,x2) = []
oneRangeQuery tree  (x1,x2) = nd ++ lftnd ++ rgtnd where
    tree' = findSplitTree tree (x1,x2)
    nd = getPointFromNode tree'
    (l,r) = getUnderTree tree'
    lftnd = oneRangeQuery l (x1,x2)
    rgtnd = oneRangeQuery r (x1,x2)

--flipping pairs in an array
replace :: [(Integer, Integer)] -> [(Integer, Integer)]
replace = map (\(l,r) -> (r,l))