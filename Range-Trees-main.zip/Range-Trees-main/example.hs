import 1DTree
import 2DTree

--example 
example = fromList2 [(1,2),(2,4),(3,1),(3,3),(3,6),(4,5),(5,2),(5,4),(5,6),(6,3),(6,4),(6,5)]
badRequest = ((2,0),(6,4))
badAnswer = oneRangeQuery2 example badRequest 
goodAnswer = [(2,4),(3,1),(3,3),(5,2),(5,4),(6,3),(6,4)]