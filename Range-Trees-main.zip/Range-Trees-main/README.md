# Range-Trees
1- and 2- Dimensional Range Searching


the complete solution is in the file range_tree
